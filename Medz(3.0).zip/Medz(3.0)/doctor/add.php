<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Update Patient Details</title>
    <style>
        .dashboard-tables, .doctor-header {
            animation: transitionIn-Y-over 0.5s;
        }
        .filter-container {
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table, #anim {
            animation: transitionIn-Y-bottom 0.5s;
        }
        .doctor-header {
            animation: transitionIn-Y-over 0.5s;
        }
    </style>
</head>
<body>
    <?php
    session_start();

    if(isset($_SESSION["user"])){
        if(($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'd'){
            header("location: ../login.php");
        } else {
            $useremail = $_SESSION["user"];
        }
    } else {
        header("location: ../login.php");
    }

    
    include("../connection.php");
    $userrow = $database->query("select * from doctor where docemail='$useremail'");
    $userfetch = $userrow->fetch_assoc();
    $userid = $userfetch["docid"];
    $username = $userfetch["docname"];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $patient_id = $_POST['patient_id'];
        $patient_name = $_POST['patient_name'];
        $patient_age = $_POST['patient_age'];
        $patient_address = $_POST['patient_address'];
        $patient_phone = $_POST['patient_phone'];

        
        $update_query = "UPDATE patient SET pname='$patient_name', age='$patient_age', address='$patient_address', pphone='$patient_phone' WHERE pid='$patient_id'";
        if ($database->query($update_query)) {
            echo "<script>alert('Patient details updated successfully!');</script>";
        } else {
            echo "<script>alert('Failed to update patient details.');</script>";
        }
    }
    ?>

    <div class="container">
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td style="padding:10px" colspan="2">
                        <table border="0" class="profile-container">
                            <tr>
                                <td width="30%" style="padding-left:20px">
                                    <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($username, 0, 13) ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($useremail, 0, 22) ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-dashbord">
                        <a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-session">
                        <a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-patient">
                        <a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-doctor menu-active">
                        <a href="add.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Update Patient Details</p></div></a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-settings">
                        <a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a>
                    </td>
                </tr>
            </table>
        </div>

        <div class="dash-body" style="margin-top: 15px">
            <table border="0" width="100%" style="border-spacing: 0;margin:0;padding:0;">
                <tr>
                    <td colspan="1" class="nav-bar">
                        <p style="font-size: 23px;padding-left:12px;font-weight: 600;margin-left:20px;">Update Patient Details</p>
                    </td>
                    <td width="25%"></td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">Today's Date</p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;">
                            <?php 
                            date_default_timezone_set('Asia/Kolkata');
                            echo date('Y-m-d'); 
                            ?>
                        </p>
                    </td>
                    <td width="10%">
                        <button class="btn-label" style="display: flex;justify-content: center;align-items: center;"><img src="../img/calendar.svg" width="100%"></button>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                           
                            <form action="add.php" method="POST" class="sub-table scrolldown" style="width: 80%;">
                                <table width="100%" class="filter-container" border="0">
                                    <tr>
                                        <td style="width: 100%; padding: 10px;">
                                            <label for="patient_id" class="form-label">Patient ID</label>
                                            <input type="text" name="patient_id" class="input-text" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%; padding: 10px;">
                                            <label for="patient_name" class="form-label">Patient Name</label>
                                            <input type="text" name="patient_name" class="input-text" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%; padding: 10px;">
                                            <label for="patient_age" class="form-label">Patient Age</label>
                                            <input type="number" name="patient_age" class="input-text" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%; padding: 10px;">
                                            <label for="patient_address" class="form-label">Patient Address</label>
                                            <input type="text" name="patient_address" class="input-text" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="width: 100%; padding: 10px;">
                                            <label for="patient_phone" class="form-label">Patient Phone</label>
                                            <input type="text" name="patient_phone" class="input-text" required>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 20px 0;">
                                            <center><button type="submit" class="btn-primary btn" style="width: 50%;">Update Personal Details</button></center>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                            
                            <form action="add_another.php" method="POST" class="sub-table scrolldown" style="width: 80%; margin-top: 40px;">
                                <table width="100%" class="filter-container" border="0">
                                <td style="width: 100%; padding: 25px;">
                 <label for="new_field1" class="form-label">Medical History</label>
             <textarea id="new_field1" name="new_field1" class="input-text" rows="4" cols="50" required></textarea>
           </td>
         </tr>
                           <td style="width: 100%; padding: 25px;">
                            <label for="new_field1" class="form-label">Medication Records</label>
                            <textarea id="new_field1" name="new_field1" class="input-text" rows="4" cols="50" required></textarea>
                            </td>
                            </tr>
                            
                          <td style="width: 100%; padding: 25px;">
                          <label for="new_field1" class="form-label">Recent Visits</label>
                          <textarea id="new_field1" name="new_field1" class="input-text" rows="4" cols="50" required></textarea>
                          </td>
                          </tr>                           
                                    <tr>
                                        <td style="padding: 20px 0;">
                                           <center> <button type="submit" class="btn-primary btn" style="width: 50%;">Update Medical Details</button></center>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
