// Function to send the user message and generate a bot response
function sendMessage() {
    const userInput = document.getElementById('userInput').value.trim();
    const chatBox = document.getElementById('chatBox');

    if (userInput === '') return;

    // Add user's message to the chat box
    const userMessageElement = document.createElement('p');
    userMessageElement.classList.add('user-message');
    userMessageElement.innerText = `You: ${userInput}`;
    chatBox.appendChild(userMessageElement);

    // Find a response from the bot
    const botResponse = getHealthResponse(userInput.toLowerCase());

    // Add bot's response to the chat box
    const botMessageElement = document.createElement('p');
    botMessageElement.innerText = `Bot: ${botResponse}`;
    chatBox.appendChild(botMessageElement);

    // Clear the input field for the next message
    document.getElementById('userInput').value = '';

    // Auto-scroll chat box to the bottom after sending message
    chatBox.scrollTop = chatBox.scrollHeight;
}

// Function to handle health-related responses
function getHealthResponse(userInput) {
    // Health-related responses based on the user's input
    if (userInput.includes("headache") || userInput.includes("head pain")) {
        return "Here are some remedies you can try for a headache:\n1. Rest in a quiet and dark room.\n2. Apply a cold or warm compress to your forehead or neck.\n3. Drink plenty of water to stay hydrated.\n4. Consider over-the-counter pain relievers like ibuprofen or acetaminophen, but always follow the recommended dosage.\n5. Practice relaxation techniques such as deep breathing or meditation.\n\nIf your headache persists or worsens, it's important to consult a healthcare professional.";
    }
    else if (userInput.includes("hi") || userInput.includes("hello")) {
        return "Hi there! How can I help you today? Feel free to ask about your Problem.";
    }else if (userInput.includes("stomach ache") || userInput.includes("stomach pain")){
        return "Remedy for Stomach Aches\n1. Rest: Lie down in a comfortable position to reduce discomfort.\n2. Hydrate: Drink clear fluids like water or diluted fruit juice to avoid dehydration.\n3. Bland diet: Eat small portions of bland foods like toast, crackers, or plain yogurt.\n4. Over-the-counter relief: Consider taking an antacid or pain reliever like ibuprofen or naproxen, following the package instructions.\n5. Warmth: Apply a heating pad or warm compress to your abdomen for temporary relief.\nIf your pain is severe, persistent, or accompanied by other symptoms, seek medical attention.";
    }else if (userInput.includes("cold")|| userInput.includes("cough")){
        return "Remedy for a Cold or Cough\n1. Rest: Get plenty of sleep.\n2. Hydrate: Drink plenty of fluids.\n3. Over-the-counter: Use OTC meds for relief.\n4. Home remedies: Try salt water gargle, humidifier, or chicken soup.\n5. Avoid irritants: Stay away from smoke and pollutants.\nIf your symptoms are severe, persistent, or accompanied by difficulty breathing, seek medical attention.";
    }else if (userInput.includes("running nose")){
        return "Remedy for a Running Nose\n1. Hydrate: Drink plenty of fluids to thin mucus.\n2. Saline rinse: Use a saline nasal spray or rinse to flush out nasal passages.\n3. Humidifier: Use a humidifier to add moisture to the air and help soothe nasal irritation.\n4. Over-the-counter: Try decongestants or nasal sprays for temporary relief.\n5. Avoid irritants: Stay away from smoke, dust, and other irritants.\nIf your symptoms are severe, persistent, or accompanied by difficulty breathing, seek medical attention.";
    }else if (userInput.includes("covid") || userInput.includes("coronavirus") || userInput.includes("corona")) {
        return "Preventing the spread of COVID-19 is crucial. Here are some general measures you can take:\n1. Wash your hands frequently with soap and water for at least 20 seconds.\n2. Wear a mask in public settings, especially when social distancing is not possible.\n3. Practice social distancing by staying at least 6 feet away from others.\n4. Avoid large gatherings and crowded indoor spaces.\n5. Stay home if you're feeling unwell, and seek medical advice if you have symptoms of COVID-19 such as fever, cough, or difficulty breathing.\n6. Get vaccinated against COVID-19 when it's available to you.\n\nFor the latest information on COVID-19, consult reputable sources such as the World Health Organization (WHO) or the Centers for Disease Control and Prevention (CDC).";
    } else if (userInput.includes("fever") || userInput.includes("viral fever")) {
        return "If you have a fever, here are some general remedies you can try to help manage your symptoms:\n1. Rest: Make sure to get plenty of rest to help your body fight off the infection.\n2. Stay hydrated: Drink plenty of fluids such as water, herbal teas, or clear broths to prevent dehydration.\n3. Over-the-counter medications: Consider taking over-the-counter fever reducers such as acetaminophen (Tylenol) or ibuprofen (Advil, Motrin) to help reduce fever and relieve discomfort. Follow the dosage instructions on the package and consult a healthcare professional if you have any questions.\n4. Cool compress: Applying a cool, damp washcloth to your forehead or taking a lukewarm bath can help reduce fever.\n5. Monitor your symptoms: Keep track of your temperature and any other symptoms you may experience. If your fever persists or worsens, or if you develop severe symptoms, seek medical attention.\n\nRemember, it's important to rest and take care of yourself when you're sick. If you have any concerns about your health, don't hesitate to consult a healthcare professional.";
    } else if (userInput.includes("cancer")) {
        return "It's a serious condition that requires professional care. Please consult a healthcare provider for proper diagnosis and treatment.";
    } else if (userInput.includes("throat pain")) {
        return "Throat pain can be uncomfortable, but there are several remedies you can try to ease the discomfort:\n1. Gargle with warm salt water: Mix half a teaspoon of salt into a glass of warm water and gargle with it several times a day to soothe the throat.\n2. Stay hydrated: Drink plenty of fluids such as water, herbal teas, or warm broths to keep your throat moist and prevent further irritation.\n3. Use lozenges or throat sprays: Over-the-counter throat lozenges or sprays containing ingredients like menthol or benzocaine can help numb the throat and provide temporary relief.\n4. Avoid irritants: Avoid smoking, as well as exposure to smoke and other irritants that can aggravate the throat.\n5. Rest your voice: Try to avoid speaking loudly or shouting, as this can strain the throat further.\n\nIf your throat pain persists for more than a few days, or if you experience difficulty swallowing, fever, or other concerning symptoms, it's important to consult a healthcare professional for further evaluation and treatment.";
    } else {
        return "I'm sorry, I'm not sure how to respond to that. Can you please ask something else related to health?";
    }
}
