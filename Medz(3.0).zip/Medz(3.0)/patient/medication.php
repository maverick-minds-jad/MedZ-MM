<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Medication Reminders</title>
    <style>
        .popup {
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table {
            animation: transitionIn-Y-bottom 0.5s;
        }
    </style>
</head>
<body>
    <?php
    session_start();

    // Check session validity
    if (isset($_SESSION["user"])) {
        if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'p') {
            header("location: ../login.php");
        } else {
            $useremail = $_SESSION["user"];
        }
    } else {
        header("location: ../login.php");
    }

    // Set timezone and today's date
    date_default_timezone_set('Asia/Kolkata');
    $today = date('Y-m-d');
    ?>

    <!-- Container for the whole layout -->
    <div class="container">
        <!-- Navigation Menu -->
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td colspan="2" style="padding:10px">
                        <table class="profile-container" border="0">
                            <tr>
                                <td width="30%" style="padding-left:20px">
                                    <img src="../img/user.png" alt="User" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($_SESSION["user"], 0, 13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($_SESSION["user"], 0, 22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-home">
                        <a href="index.php" class="non-style-link-menu">
                            <div><p class="menu-text">Home</p></div>
                        </a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-session">
                        <a href="medication.php" class="non-style-link-menu non-style-link-menu-active">
                            <div><p class="menu-text">Medication Reminders</p></div>
                        </a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="records.php" class="non-style-link-menu">
                            <div><p class="menu-text">Patient Records</p></div>
                        </a>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Main content area to display medication reminders -->
        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0;margin:0;padding:0;margin-top:25px;">
                <tr>
                    <td width="13%">
                        <a href="medication.php">
                            <button class="login-btn btn-primary-soft btn btn-icon-back" style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px">
                                <font class="tn-in-text">Back</font>
                            </button>
                        </a>
                    </td>
                    <td>
                        <form action="medication.php" method="post" class="header-search">
                            <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Medication reminders" list="medications">&nbsp;&nbsp;
                            <datalist id="medications">
                                <option value="Aspirin">
                                <option value="Lisinopril">
                                <option value="Metformin">
                                <option value="Atorvastatin">
                                <option value="Albuterol">
                            </datalist>
                            <input type="submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                        </form>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">Today's Date</p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;"><?php echo $today; ?></p>
                    </td>
                    <td width="10%">
                        <button class="btn-label" style="display: flex;justify-content: center;align-items: center;">
                            <img src="../img/calendar.svg" width="100%">
                        </button>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="abc scroll">
                                <table width="100%" class="sub-table scrolldown" border="0" style="padding: 50px;border:none">
                                    <tbody>
                                        <?php
                                        // Static sample medication reminders
                                        $sampleMedications = [
                                            ["medication_name" => "Aspirin", "reminder_date" => "2024-09-11", "instructions" => "Take one tablet daily after meals."],
                                            ["medication_name" => "Dolo 650", "reminder_date" => "2024-09-12", "instructions" => "Take one tablet every morning."],
                                            ["medication_name" => "Metformin", "reminder_date" => "2024-09-13", "instructions" => "Take one tablet twice daily with meals."],
                                            ["medication_name" => "Atorvastatin", "reminder_date" => "2024-09-14", "instructions" => "Take one tablet every night before bed."],
                                            ["medication_name" => "Albuterol", "reminder_date" => "2024-09-15", "instructions" => "Use inhaler as needed, up to 4 times per day."]
                                        ];

                                        // Display the sample reminders
                                        foreach ($sampleMedications as $medication) {
                                            echo '
                                            <tr>
                                                <td style="width: 50%;">
                                                    <div class="dashboard-items search-items">
                                                        <div style="width:100%">
                                                            <div class="h1-search" style="font-size:25px;">Medication Reminder</div><br>
                                                            <div class="h3-search" style="font-size:18px;line-height:30px">
                                                                Medication Name: <b>' . $medication["medication_name"] . '</b><br>
                                                                Reminder Date: <b>' . $medication["reminder_date"] . '</b><br>
                                                                Instructions: <b>' . $medication["instructions"] . '</b>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </center>
                    </td> 
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
