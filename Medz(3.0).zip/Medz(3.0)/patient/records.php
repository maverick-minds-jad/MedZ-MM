<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
    <title>Patient Records</title>
    <style>
        .popup {
            animation: transitionIn-Y-bottom 0.5s;
        }
        .sub-table {
            animation: transitionIn-Y-bottom 0.5s;
        }
        .record-section {
            margin: 20px 0;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .record-title {
            font-size: 18px;
            font-weight: bold;
            color: #333;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php
    session_start();

    // Check session validity
    if (isset($_SESSION["user"])) {
        if (($_SESSION["user"]) == "" || $_SESSION['usertype'] != 'p') {
            header("location: ../login.php");
        } else {
            $useremail = $_SESSION["user"];
        }
    } else {
        header("location: ../login.php");
    }

    // Set timezone and today's date
    date_default_timezone_set('Asia/Kolkata');
    $today = date('Y-m-d');
    ?>

    <!-- Container for the whole layout -->
    <div class="container">
        <!-- Navigation Menu -->
        <div class="menu">
            <table class="menu-container" border="0">
                <tr>
                    <td colspan="2" style="padding:10px">
                        <table class="profile-container" border="0">
                            <tr>
                                <td width="30%" style="padding-left:20px">
                                    <img src="../img/user.png" alt="User" width="100%" style="border-radius:50%">
                                </td>
                                <td style="padding:0px;margin:0px;">
                                    <p class="profile-title"><?php echo substr($_SESSION["user"], 0, 13); ?>..</p>
                                    <p class="profile-subtitle"><?php echo substr($_SESSION["user"], 0, 22); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">
                                    <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-home">
                        <a href="index.php" class="non-style-link-menu">
                            <div><p class="menu-text">Home</p></div>
                        </a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-session">
                        <a href="medication.php" class="non-style-link-menu">
                            <div><p class="menu-text">Medication Reminders</p></div>
                        </a>
                    </td>
                </tr>
                <tr class="menu-row">
                    <td class="menu-btn menu-icon-appoinment">
                        <a href="records.php" class="non-style-link-menu non-style-link-menu-active">
                            <div><p class="menu-text">Patient Records</p></div>
                        </a>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Main content area to display detailed patient records -->
        <div class="dash-body">
            <table border="0" width="100%" style="border-spacing: 0;margin:0;padding:0;margin-top:25px;">
                <tr>
                    <td width="13%">
                        <a href="records.php">
                            <button class="login-btn btn-primary-soft btn btn-icon-back" style="padding-top:11px;padding-bottom:11px;margin-left:20px;width:125px">
                                <font class="tn-in-text">Back</font>
                            </button>
                        </a>
                    </td>
                    <td>
                        <form action="records.php" method="post" class="header-search">
                            <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Patient Records" list="patients">&nbsp;&nbsp;
                            <datalist id="patients">
                                <option value="John Doe">
                                <option value="Jane Smith">
                            </datalist>
                            <input type="submit" value="Search" class="login-btn btn-primary btn" style="padding-left: 25px;padding-right: 25px;padding-top: 10px;padding-bottom: 10px;">
                        </form>
                    </td>
                    <td width="15%">
                        <p style="font-size: 14px;color: rgb(119, 119, 119);padding: 0;margin: 0;text-align: right;">Today's Date</p>
                        <p class="heading-sub12" style="padding: 0;margin: 0;"><?php echo $today; ?></p>
                    </td>
                    <td width="10%">
                        <button class="btn-label" style="display: flex;justify-content: center;align-items: center;">
                            <img src="../img/calendar.svg" width="100%">
                        </button>
                    </td>
                </tr>
                <tr>
                    <td colspan="4">
                        <center>
                            <div class="abc scroll">
                                <div class="sub-table scrolldown" style="padding: 50px;border:none">
                                    <!-- Patient Details Section -->
                                    <div class="record-section">
                                        <p class="record-title">Patient Details</p>
                                        <p><strong>Name:</strong> Ram kumar</p>
                                        <p><strong>Age:</strong> 45</p>
                                        <p><strong>Gender:</strong> Male</p>
                                        <p><strong>Blood Type:</strong> O+</p>
                                        <p><strong>Contact:</strong> +91-1234567890</p>
                                        <p><strong>Address:</strong> Main Street, chennai, india</p>
                                    </div>

                                    <!-- Medical History Section -->
                                    <div class="record-section">
                                        <p class="record-title">Medical History</p>
                                        <ul>
                                            <li>Hypertension - Diagnosed in 2020</li>
                                            <li>Type 2 Diabetes - Diagnosed in 2018</li>
                                            <li>Asthma - Diagnosed in 2015</li>
                                            <li>Previous Surgery: Appendectomy in 2012</li>
                                        </ul>
                                    </div>

                                    <!-- Medication Records Section -->
                                    <div class="record-section">
                                        <p class="record-title">Current Medications</p>
                                        <table width="100%" border="1" style="border-collapse: collapse;">
                                            <thead>
                                                <tr>
                                                    <th>Medication</th>
                                                    <th>Dosage</th>
                                                    <th>Frequency</th>
                                                    <th>Start Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Metformin</td>
                                                    <td>500 mg</td>
                                                    <td>Twice a day</td>
                                                    <td>2024-08-01</td>
                                                </tr>
                                                <tr>
                                                    <td>Lisinopril</td>
                                                    <td>20 mg</td>
                                                    <td>Once a day</td>
                                                    <td>2024-08-10</td>
                                                </tr>
                                                <tr>
                                                    <td>Ventolin Inhaler</td>
                                                    <td>As needed</td>
                                                    <td>As needed</td>
                                                    <td>2024-08-20</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Allergies Section -->
                                    <div class="record-section">
                                        <p class="record-title">Allergies</p>
                                        <ul>
                                            <li>Penicillin</li>
                                            <li>Nuts</li>
                                        </ul>
                                    </div>

                                    <!-- Recent Visits Section -->
                                    <div class="record-section">
                                        <p class="record-title">Recent Visits</p>
                                        <table width="100%" border="1" style="border-collapse: collapse;">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Reason for Visit</th>
                                                    <th>Doctor</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>2024-09-01</td>
                                                    <td>Routine Check-up</td>
                                                    <td>Dr. Ahmed</td>
                                                </tr>
                                                <tr>
                                                    <td>2024-08-20</td>
                                                    <td>Blood Pressure Management</td>
                                                    <td>Dr. Sunita</td>
                                                </tr>
                                                <tr>
                                                    <td>2024-08-05</td>
                                                    <td>Asthma Control</td>
                                                    <td>Dr. John</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </center>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>
